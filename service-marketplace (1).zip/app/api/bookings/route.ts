import { NextResponse } from "next/server"

// Sample data for bookings
const bookings = [
  {
    id: 1,
    userId: 1,
    serviceId: 1,
    providerId: 1,
    date: "2023-06-15",
    time: "10:00 AM",
    status: "confirmed",
    address: "123 Main St, Apartment 4B",
    price: 499,
    createdAt: "2023-06-10T12:00:00Z",
  },
  {
    id: 2,
    userId: 1,
    serviceId: 2,
    providerId: 2,
    date: "2023-06-20",
    time: "2:30 PM",
    status: "pending",
    address: "456 Park Ave, Suite 7C",
    price: 799,
    createdAt: "2023-06-11T14:30:00Z",
  },
  {
    id: 3,
    userId: 2,
    serviceId: 3,
    providerId: 3,
    date: "2023-05-28",
    time: "11:00 AM",
    status: "completed",
    address: "789 Broadway, Apt 12D",
    price: 349,
    createdAt: "2023-05-25T09:15:00Z",
  },
]

export async function GET(request: Request) {
  // Get the URL from the request
  const url = new URL(request.url)

  // Get query parameters
  const userId = url.searchParams.get("userId")
  const providerId = url.searchParams.get("providerId")
  const status = url.searchParams.get("status")

  // Filter bookings based on query parameters
  let filteredBookings = [...bookings]

  if (userId) {
    filteredBookings = filteredBookings.filter((booking) => booking.userId === Number.parseInt(userId))
  }

  if (providerId) {
    filteredBookings = filteredBookings.filter((booking) => booking.providerId === Number.parseInt(providerId))
  }

  if (status) {
    filteredBookings = filteredBookings.filter((booking) => booking.status === status)
  }

  // Return the filtered bookings
  return NextResponse.json(filteredBookings)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate the request body
    if (!body.userId || !body.serviceId || !body.date || !body.time || !body.address) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real application, you would save this to a database
    // For this example, we'll just return the created booking with a mock ID
    const newBooking = {
      id: bookings.length + 1,
      userId: body.userId,
      serviceId: body.serviceId,
      providerId: body.providerId || null,
      date: body.date,
      time: body.time,
      status: "pending",
      address: body.address,
      price: body.price,
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(newBooking, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create booking" }, { status: 500 })
  }
}
