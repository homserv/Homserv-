import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Calendar, CheckCircle, Clock, MapPin, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

// This would typically come from a database
const serviceDetails = {
  id: 1,
  title: "Home Cleaning",
  description:
    "Professional home cleaning services for a spotless home. Our trained professionals use high-quality cleaning products and equipment to ensure your home is thoroughly cleaned.",
  longDescription:
    "Our professional home cleaning service is designed to give you a spotless home without the hassle. Our trained and verified cleaning professionals use high-quality, eco-friendly cleaning products and professional equipment to ensure your home is thoroughly cleaned from top to bottom. We offer customizable cleaning plans to meet your specific needs and schedule. Whether you need a one-time deep clean or regular maintenance cleaning, we've got you covered.",
  rating: 4.8,
  reviews: 1240,
  price: 499,
  image: "/placeholder.svg?height=400&width=600",
  category: "Cleaning",
  duration: "3 hours",
  inclusions: [
    "Dusting of all accessible surfaces",
    "Vacuuming of carpets and rugs",
    "Mopping of all floors",
    "Cleaning of kitchen countertops and appliances",
    "Cleaning of bathroom fixtures and surfaces",
    "Emptying trash bins",
  ],
  exclusions: [
    "Cleaning of walls and ceilings",
    "Cleaning inside cabinets and drawers",
    "Cleaning of windows from outside",
    "Moving heavy furniture",
    "Cleaning of chandeliers and high fixtures",
  ],
  faqs: [
    {
      question: "How long does a typical cleaning session take?",
      answer:
        "A standard home cleaning typically takes 2-3 hours for a 2-bedroom apartment. The duration may vary based on the size of your home and the level of cleaning required.",
    },
    {
      question: "Do I need to provide cleaning supplies?",
      answer:
        "No, our professionals bring all necessary cleaning supplies and equipment. However, if you prefer specific products to be used in your home, you can provide them.",
    },
    {
      question: "Is there a cancellation fee?",
      answer:
        "Cancellations made at least 24 hours before the scheduled service are free of charge. For cancellations made within 24 hours, a cancellation fee of 50% of the service price may apply.",
    },
    {
      question: "Are your cleaning professionals verified?",
      answer:
        "Yes, all our cleaning professionals undergo thorough background checks and verification processes before joining our platform. They are also trained in professional cleaning techniques.",
    },
  ],
  professionals: [
    {
      id: 1,
      name: "Sarah Johnson",
      rating: 4.9,
      reviews: 320,
      image: "/placeholder.svg?height=100&width=100",
      experience: "5 years",
    },
    {
      id: 2,
      name: "Michael Chen",
      rating: 4.8,
      reviews: 280,
      image: "/placeholder.svg?height=100&width=100",
      experience: "3 years",
    },
    {
      id: 3,
      name: "Priya Sharma",
      rating: 4.7,
      reviews: 210,
      image: "/placeholder.svg?height=100&width=100",
      experience: "4 years",
    },
  ],
}

export default function ServiceDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="mb-6">
        <Link href="/services" className="flex items-center text-muted-foreground hover:text-foreground">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Services
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="space-y-8">
            {/* Service Header */}
            <div>
              <h1 className="text-3xl font-bold tracking-tight mb-2">{serviceDetails.title}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center">
                  <Star className="h-4 w-4 fill-primary text-primary mr-1" />
                  <span className="font-medium">{serviceDetails.rating}</span>
                  <span className="text-muted-foreground ml-1">({serviceDetails.reviews} reviews)</span>
                </div>
                <Badge>{serviceDetails.category}</Badge>
              </div>
              <p className="text-muted-foreground">{serviceDetails.description}</p>
            </div>

            {/* Service Image */}
            <div className="relative h-[300px] md:h-[400px] w-full rounded-lg overflow-hidden">
              <Image
                src={serviceDetails.image || "/placeholder.svg"}
                alt={serviceDetails.title}
                fill
                className="object-cover"
              />
            </div>

            {/* Service Details Tabs */}
            <Tabs defaultValue="details">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="inclusions">Inclusions</TabsTrigger>
                <TabsTrigger value="professionals">Professionals</TabsTrigger>
                <TabsTrigger value="faqs">FAQs</TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="pt-4">
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold">About this service</h3>
                  <p>{serviceDetails.longDescription}</p>
                  <div className="grid grid-cols-2 gap-4 mt-6">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Duration</p>
                        <p className="font-medium">{serviceDetails.duration}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 mr-2 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Location</p>
                        <p className="font-medium">At your home</p>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="inclusions" className="pt-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold mb-4">What's Included</h3>
                    <ul className="space-y-2">
                      {serviceDetails.inclusions.map((item, index) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5 shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Separator />
                  <div>
                    <h3 className="text-xl font-semibold mb-4">What's Not Included</h3>
                    <ul className="space-y-2">
                      {serviceDetails.exclusions.map((item, index) => (
                        <li key={index} className="flex items-start">
                          <span className="h-5 w-5 flex items-center justify-center text-destructive mr-2 shrink-0">
                            ✕
                          </span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="professionals" className="pt-4">
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold mb-4">Our Professionals</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {serviceDetails.professionals.map((pro) => (
                      <Card key={pro.id}>
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div className="relative h-16 w-16 rounded-full overflow-hidden">
                              <Image
                                src={pro.image || "/placeholder.svg"}
                                alt={pro.name}
                                fill
                                className="object-cover"
                              />
                            </div>
                            <div>
                              <h4 className="font-semibold">{pro.name}</h4>
                              <div className="flex items-center">
                                <Star className="h-3 w-3 fill-primary text-primary mr-1" />
                                <span className="text-sm">{pro.rating}</span>
                                <span className="text-xs text-muted-foreground ml-1">({pro.reviews} reviews)</span>
                              </div>
                              <p className="text-sm text-muted-foreground">Experience: {pro.experience}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="faqs" className="pt-4">
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold mb-4">Frequently Asked Questions</h3>
                  <div className="space-y-4">
                    {serviceDetails.faqs.map((faq, index) => (
                      <div key={index} className="space-y-2">
                        <h4 className="font-semibold">{faq.question}</h4>
                        <p className="text-muted-foreground">{faq.answer}</p>
                        {index < serviceDetails.faqs.length - 1 && <Separator className="mt-4" />}
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Booking Card */}
        <div className="lg:col-span-1">
          <Card className="sticky top-24">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4">Book this service</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Price</span>
                  <span className="font-bold text-2xl">₹{serviceDetails.price}</span>
                </div>
                <Separator />
                <div>
                  <h4 className="font-medium mb-2">Select Date & Time</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <Button variant="outline" className="justify-start">
                      <Calendar className="mr-2 h-4 w-4" />
                      Select Date
                    </Button>
                    <Button variant="outline" className="justify-start">
                      <Clock className="mr-2 h-4 w-4" />
                      Select Time
                    </Button>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Your Address</h4>
                  <Button variant="outline" className="w-full justify-start">
                    <MapPin className="mr-2 h-4 w-4" />
                    Add Address
                  </Button>
                </div>
                <Button className="w-full">Book Now</Button>
                <p className="text-xs text-center text-muted-foreground">
                  By booking, you agree to our Terms of Service and Privacy Policy
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
