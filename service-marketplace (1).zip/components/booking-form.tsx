"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Calendar, MapPin } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { createBooking } from "@/app/actions/booking-actions"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

interface BookingFormProps {
  serviceId: number
  serviceName: string
  servicePrice: number
  providerId?: number
}

export default function BookingForm({ serviceId, serviceName, servicePrice, providerId }: BookingFormProps) {
  const router = useRouter()
  const [date, setDate] = useState<Date>()
  const [time, setTime] = useState<string>("")
  const [address, setAddress] = useState<string>("")
  const [notes, setNotes] = useState<string>("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showSuccessDialog, setShowSuccessDialog] = useState(false)
  const [bookingResult, setBookingResult] = useState<{
    success: boolean
    message: string
    booking?: any
  } | null>(null)

  // Sample time slots
  const timeSlots = [
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM",
    "06:00 PM",
    "07:00 PM",
  ]

  // Sample addresses
  const addresses = [
    {
      id: 1,
      addressLine1: "123 Main St",
      addressLine2: "Apartment 4B",
      city: "Mumbai",
      state: "Maharashtra",
      postalCode: "400001",
    },
    {
      id: 2,
      addressLine1: "456 Park Ave",
      addressLine2: "Suite 7C",
      city: "Delhi",
      state: "Delhi",
      postalCode: "110001",
    },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!date || !time || !address) {
      alert("Please fill in all required fields")
      return
    }

    setIsSubmitting(true)

    try {
      // In a real app, you would use the actual address ID from the user's saved addresses
      const addressId = Number.parseInt(address)

      const formData = new FormData()
      formData.append("serviceId", serviceId.toString())
      formData.append("date", format(date, "yyyy-MM-dd"))
      formData.append("time", time)
      formData.append("addressId", addressId.toString())
      formData.append("price", servicePrice.toString())

      if (notes) {
        formData.append("notes", notes)
      }

      if (providerId) {
        formData.append("providerId", providerId.toString())
      }

      const result = await createBooking(formData)
      setBookingResult(result)

      if (result.success) {
        setShowSuccessDialog(true)
      } else {
        alert(result.message)
      }
    } catch (error) {
      console.error("Error booking service:", error)
      alert("An error occurred while booking the service. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCloseSuccessDialog = () => {
    setShowSuccessDialog(false)
    router.push("/dashboard/bookings")
  }

  return (
    <>
      <Card>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold mb-4">Book this service</h3>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Service</span>
                <span className="font-medium">{serviceName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Price</span>
                <span className="font-bold text-2xl">₹{servicePrice}</span>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-2">Select Date</h4>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <Calendar className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                      disabled={(date) => date < new Date()}
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div>
                <h4 className="font-medium mb-2">Select Time</h4>
                <div className="grid grid-cols-3 gap-2">
                  {timeSlots.map((slot) => (
                    <Button
                      key={slot}
                      type="button"
                      variant={time === slot ? "default" : "outline"}
                      className={cn("h-10", time === slot && "bg-primary text-primary-foreground")}
                      onClick={() => setTime(slot)}
                    >
                      {slot}
                    </Button>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Select Address</h4>
                <div className="space-y-2">
                  {addresses.map((addr) => (
                    <Button
                      key={addr.id}
                      type="button"
                      variant={address === addr.id.toString() ? "default" : "outline"}
                      className="w-full justify-start text-left h-auto py-3"
                      onClick={() => setAddress(addr.id.toString())}
                    >
                      <MapPin className="mr-2 h-4 w-4 shrink-0" />
                      <div className="text-left">
                        <p>{addr.addressLine1}</p>
                        {addr.addressLine2 && <p>{addr.addressLine2}</p>}
                        <p>
                          {addr.city}, {addr.state} {addr.postalCode}
                        </p>
                      </div>
                    </Button>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={() => alert("Add address functionality would go here")}
                  >
                    + Add New Address
                  </Button>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-2">Special Instructions (Optional)</h4>
                <Textarea
                  placeholder="Any special requirements or instructions for the service provider..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="resize-none"
                />
              </div>
              <Button type="submit" className="w-full" disabled={isSubmitting || !date || !time || !address}>
                {isSubmitting ? "Processing..." : "Book Now"}
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                By booking, you agree to our Terms of Service and Privacy Policy
              </p>
            </div>
          </form>
        </CardContent>
      </Card>

      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Booking Successful!</DialogTitle>
            <DialogDescription>Your service has been booked successfully.</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">Service:</span>
                <span>{serviceName}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Date:</span>
                <span>{date ? format(date, "PPP") : ""}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Time:</span>
                <span>{time}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Amount:</span>
                <span>₹{servicePrice}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Booking ID:</span>
                <span>{bookingResult?.booking?.id || "N/A"}</span>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleCloseSuccessDialog}>View My Bookings</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
