import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)

    const serviceId = url.searchParams.get("serviceId")
    const isVerified = url.searchParams.get("verified") === "true"

    // Build the query filter
    const filter: any = {
      isVerified,
      isActive: true,
    }

    if (serviceId) {
      filter.providerServices = {
        some: {
          serviceId: Number.parseInt(serviceId),
          isAvailable: true,
        },
      }
    }

    // Query the database
    const providers = await prisma.provider.findMany({
      where: filter,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        providerServices: {
          include: {
            service: true,
          },
        },
      },
    })

    return NextResponse.json(providers)
  } catch (error) {
    console.error("Error fetching providers:", error)
    return NextResponse.json({ error: "Failed to fetch providers" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate the request body
    if (!body.userId || !body.bio) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if provider already exists
    const existingProvider = await prisma.provider.findUnique({
      where: {
        userId: body.userId,
      },
    })

    if (existingProvider) {
      return NextResponse.json({ error: "Provider profile already exists for this user" }, { status: 409 })
    }

    // Create provider profile
    const provider = await prisma.provider.create({
      data: {
        userId: body.userId,
        bio: body.bio,
        experience: body.experience || null,
        isVerified: false, // New providers need verification
        isActive: true,
      },
    })

    return NextResponse.json(provider, { status: 201 })
  } catch (error) {
    console.error("Error creating provider:", error)
    return NextResponse.json({ error: "Failed to create provider profile" }, { status: 500 })
  }
}
