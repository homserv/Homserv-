import Link from "next/link"
import { BarChart3, CalendarDays, DollarSign, Home, Package, Settings, User, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Sample data for platform stats
const platformStats = {
  totalUsers: 12450,
  totalProviders: 850,
  totalBookings: 28750,
  totalRevenue: 1250000,
}

// Sample data for recent bookings
const recentBookings = [
  {
    id: "B-12345",
    service: "Home Cleaning",
    customer: "John Doe",
    provider: "Sarah Johnson",
    date: "2023-06-15",
    status: "completed",
    amount: 499,
  },
  {
    id: "B-12346",
    service: "Salon at Home",
    customer: "Jane Smith",
    provider: "Michael Chen",
    date: "2023-06-15",
    status: "confirmed",
    amount: 799,
  },
  {
    id: "B-12347",
    service: "Plumbing Services",
    customer: "Robert Brown",
    provider: "Priya Sharma",
    date: "2023-06-14",
    status: "cancelled",
    amount: 349,
  },
  {
    id: "B-12348",
    service: "Electrician",
    customer: "Emily Wilson",
    provider: "Pending Assignment",
    date: "2023-06-14",
    status: "pending",
    amount: 399,
  },
  {
    id: "B-12349",
    service: "Home Cleaning",
    customer: "David Miller",
    provider: "Sarah Johnson",
    date: "2023-06-13",
    status: "completed",
    amount: 499,
  },
]

// Sample data for new providers
const newProviders = [
  {
    id: "P-5001",
    name: "Alex Johnson",
    service: "Electrician",
    joinDate: "2023-06-14",
    status: "pending",
  },
  {
    id: "P-5002",
    name: "Maria Garcia",
    service: "Beauty Specialist",
    joinDate: "2023-06-13",
    status: "pending",
  },
  {
    id: "P-5003",
    name: "Raj Patel",
    service: "Plumber",
    joinDate: "2023-06-12",
    status: "approved",
  },
]

export default function AdminDashboardPage() {
  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-8">
        {/* Sidebar */}
        <div className="hidden md:block">
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Dashboard</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard">
                    <Home className="mr-2 h-4 w-4" />
                    Overview
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard/bookings">
                    <CalendarDays className="mr-2 h-4 w-4" />
                    Bookings
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard/users">
                    <User className="mr-2 h-4 w-4" />
                    Customers
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard/providers">
                    <Users className="mr-2 h-4 w-4" />
                    Service Providers
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard/services">
                    <Package className="mr-2 h-4 w-4" />
                    Services
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard/reports">
                    <BarChart3 className="mr-2 h-4 w-4" />
                    Reports
                  </Link>
                </Button>
              </div>
            </div>
            <Separator />
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Settings</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/admin/dashboard/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    Platform Settings
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage your platform, users, and services.</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                    <User className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">{platformStats.totalUsers.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground mt-1">+125 this week</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">Service Providers</p>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">{platformStats.totalProviders.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground mt-1">+18 this week</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">Total Bookings</p>
                    <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">{platformStats.totalBookings.toLocaleString()}</div>
                  <p className="text-xs text-muted-foreground mt-1">+450 this week</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">₹{(platformStats.totalRevenue / 100000).toFixed(2)}L</div>
                  <p className="text-xs text-muted-foreground mt-1">+₹2.1L this week</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Bookings */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Bookings</CardTitle>
              <CardDescription>Latest service bookings across the platform</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Booking ID</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentBookings.map((booking) => (
                    <TableRow key={booking.id}>
                      <TableCell className="font-medium">{booking.id}</TableCell>
                      <TableCell>{booking.service}</TableCell>
                      <TableCell>{booking.customer}</TableCell>
                      <TableCell>{booking.provider}</TableCell>
                      <TableCell>{new Date(booking.date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            booking.status === "completed"
                              ? "default"
                              : booking.status === "confirmed"
                                ? "outline"
                                : booking.status === "cancelled"
                                  ? "destructive"
                                  : "secondary"
                          }
                        >
                          {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">₹{booking.amount}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="flex justify-end mt-4">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/admin/dashboard/bookings">View All Bookings</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* New Provider Approvals */}
          <Card>
            <CardHeader>
              <CardTitle>New Provider Approvals</CardTitle>
              <CardDescription>Service providers waiting for approval</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Provider ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Join Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {newProviders.map((provider) => (
                    <TableRow key={provider.id}>
                      <TableCell className="font-medium">{provider.id}</TableCell>
                      <TableCell>{provider.name}</TableCell>
                      <TableCell>{provider.service}</TableCell>
                      <TableCell>{new Date(provider.joinDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge variant={provider.status === "approved" ? "default" : "secondary"}>
                          {provider.status.charAt(0).toUpperCase() + provider.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                          {provider.status === "pending" && <Button size="sm">Approve</Button>}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="flex justify-end mt-4">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/admin/dashboard/providers">Manage All Providers</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
