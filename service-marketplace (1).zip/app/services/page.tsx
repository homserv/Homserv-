"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Filter, Search, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"

// Types
interface Service {
  id: number
  title: string
  description: string
  price: number
  image: string
  category: string
}

// Categories for filtering
const categories = [
  { id: "cleaning", name: "Cleaning" },
  { id: "beauty", name: "Beauty" },
  { id: "repairs", name: "Repairs" },
  { id: "appliances", name: "Appliances" },
  { id: "painting", name: "Painting" },
  { id: "pest-control", name: "Pest Control" },
]

export default function ServicesPage() {
  const [services, setServices] = useState<Service[]>([])
  const [filteredServices, setFilteredServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [sortOption, setSortOption] = useState("featured")

  // Fetch services
  useEffect(() => {
    const fetchServices = async () => {
      try {
        // In a real app, you would fetch from your API
        // const response = await fetch('/api/services')
        // const data = await response.json()

        // For demo purposes, we'll use sample data
        const sampleServices = [
          {
            id: 1,
            title: "Home Cleaning",
            description: "Professional home cleaning services for a spotless home.",
            price: 499,
            image: "/placeholder.svg?height=200&width=300",
            category: "Cleaning",
            rating: 4.8,
            reviews: 1240,
          },
          {
            id: 2,
            title: "Salon at Home",
            description: "Professional beauty services in the comfort of your home.",
            price: 799,
            image: "/placeholder.svg?height=200&width=300",
            category: "Beauty",
            rating: 4.7,
            reviews: 980,
          },
          {
            id: 3,
            title: "Plumbing Services",
            description: "Expert plumbing services for all your needs.",
            price: 349,
            image: "/placeholder.svg?height=200&width=300",
            category: "Repairs",
            rating: 4.6,
            reviews: 750,
          },
          {
            id: 4,
            title: "Electrician",
            description: "Professional electrical services for your home.",
            price: 399,
            image: "/placeholder.svg?height=200&width=300",
            category: "Repairs",
            rating: 4.5,
            reviews: 620,
          },
          {
            id: 5,
            title: "Pest Control",
            description: "Effective pest control services for a pest-free home.",
            price: 599,
            image: "/placeholder.svg?height=200&width=300",
            category: "Cleaning",
            rating: 4.4,
            reviews: 480,
          },
          {
            id: 6,
            title: "Painting",
            description: "Professional painting services for your home.",
            price: 1499,
            image: "/placeholder.svg?height=200&width=300",
            category: "Painting",
            rating: 4.3,
            reviews: 350,
          },
          {
            id: 7,
            title: "AC Repair",
            description: "Expert AC repair and maintenance services.",
            price: 699,
            image: "/placeholder.svg?height=200&width=300",
            category: "Appliances",
            rating: 4.2,
            reviews: 280,
          },
          {
            id: 8,
            title: "Furniture Assembly",
            description: "Professional furniture assembly services.",
            price: 299,
            image: "/placeholder.svg?height=200&width=300",
            category: "Repairs",
            rating: 4.1,
            reviews: 210,
          },
        ]

        setServices(sampleServices)
        setFilteredServices(sampleServices)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching services:", error)
        setLoading(false)
      }
    }

    fetchServices()
  }, [])

  // Filter and sort services
  useEffect(() => {
    let result = [...services]

    // Apply category filter
    if (selectedCategories.length > 0) {
      result = result.filter((service) => selectedCategories.includes(service.category.toLowerCase()))
    }

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (service) => service.title.toLowerCase().includes(query) || service.description.toLowerCase().includes(query),
      )
    }

    // Apply sorting
    switch (sortOption) {
      case "price-low":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        result.sort((a, b) => b.price - a.price)
        break
      case "rating":
        result.sort((a, b) => (b.rating || 0) - (a.rating || 0))
        break
      // Default is "featured", no sorting needed
    }

    setFilteredServices(result)
  }, [services, selectedCategories, searchQuery, sortOption])

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category.toLowerCase()])
    } else {
      setSelectedCategories(selectedCategories.filter((c) => c !== category.toLowerCase()))
    }
  }

  const handleSortChange = (value: string) => {
    setSortOption(value)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // The filtering is already handled by the useEffect
  }

  const clearFilters = () => {
    setSelectedCategories([])
    setSearchQuery("")
    setSortOption("featured")
  }

  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">Services</h1>
          <p className="text-muted-foreground">Browse and book professional services for your needs</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" className="md:hidden">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <SheetHeader>
                <SheetTitle>Filters</SheetTitle>
                <SheetDescription>Filter services by category and other criteria</SheetDescription>
              </SheetHeader>
              <div className="py-4">
                <h3 className="font-medium mb-2">Categories</h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`mobile-${category.id}`}
                        checked={selectedCategories.includes(category.name.toLowerCase())}
                        onCheckedChange={(checked) => handleCategoryChange(category.name, checked as boolean)}
                      />
                      <Label htmlFor={`mobile-${category.id}`}>{category.name}</Label>
                    </div>
                  ))}
                </div>
                <Separator className="my-4" />
                <Button onClick={clearFilters} variant="outline" className="w-full">
                  Clear Filters
                </Button>
              </div>
            </SheetContent>
          </Sheet>
          <Select value={sortOption} onValueChange={handleSortChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-8">
        {/* Filters - Desktop */}
        <div className="hidden md:block">
          <div className="space-y-6">
            <div>
              <h3 className="font-medium mb-4">Search</h3>
              <form onSubmit={handleSearch} className="flex gap-2">
                <Input
                  placeholder="Search services..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Button type="submit" size="icon">
                  <Search className="h-4 w-4" />
                </Button>
              </form>
            </div>
            <Separator />
            <div>
              <h3 className="font-medium mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={category.id}
                      checked={selectedCategories.includes(category.name.toLowerCase())}
                      onCheckedChange={(checked) => handleCategoryChange(category.name, checked as boolean)}
                    />
                    <Label htmlFor={category.id}>{category.name}</Label>
                  </div>
                ))}
              </div>
            </div>
            <Separator />
            <Button onClick={clearFilters} variant="outline" className="w-full">
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Services Grid */}
        <div>
          {/* Mobile Search */}
          <div className="mb-6 md:hidden">
            <form onSubmit={handleSearch} className="flex gap-2">
              <Input
                placeholder="Search services..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" size="icon">
                <Search className="h-4 w-4" />
              </Button>
            </form>
          </div>

          {/* Active Filters */}
          {selectedCategories.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedCategories.map((category) => (
                <Badge key={category} variant="secondary" className="flex items-center gap-1">
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                  <button
                    onClick={() => handleCategoryChange(category, false)}
                    className="ml-1 rounded-full hover:bg-muted p-0.5"
                  >
                    <span className="sr-only">Remove</span>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 6 6 18" />
                      <path d="m6 6 12 12" />
                    </svg>
                  </button>
                </Badge>
              ))}
              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={clearFilters}>
                Clear All
              </Button>
            </div>
          )}

          {/* Results Count */}
          <div className="mb-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredServices.length} of {services.length} services
            </p>
          </div>

          {/* Services Grid */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredServices.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredServices.map((service) => (
                <Link key={service.id} href={`/services/${service.id}`}>
                  <Card className="overflow-hidden transition-all duration-200 hover:shadow-lg">
                    <div className="relative h-48 w-full">
                      <Image
                        src={service.image || "/placeholder.svg"}
                        alt={service.title}
                        fill
                        className="object-cover"
                      />
                      <Badge className="absolute top-3 right-3">{service.category}</Badge>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-lg mb-2">{service.title}</h3>
                      <div className="flex items-center mb-2">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-primary text-primary mr-1" />
                          <span className="font-medium">{service.rating}</span>
                        </div>
                        <span className="text-muted-foreground text-sm ml-2">({service.reviews} reviews)</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-lg">₹{service.price}</p>
                        <span className="text-sm text-muted-foreground">Starting price</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium mb-2">No services found</h3>
              <p className="text-muted-foreground mb-4">Try adjusting your filters or search query</p>
              <Button onClick={clearFilters}>Clear Filters</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
