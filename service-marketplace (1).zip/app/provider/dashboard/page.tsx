import Link from "next/link"
import { CalendarDays, Clock, CreditCard, Home, Settings, User, Star, DollarSign, BarChart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"

// Sample data for upcoming jobs
const upcomingJobs = [
  {
    id: 1,
    service: "Home Cleaning",
    date: "2023-06-15",
    time: "10:00 AM",
    status: "confirmed",
    customer: "John Doe",
    address: "123 Main St, Apartment 4B",
    price: 499,
  },
  {
    id: 2,
    service: "Home Cleaning",
    date: "2023-06-20",
    time: "2:30 PM",
    status: "confirmed",
    customer: "Jane Smith",
    address: "456 Park Ave, Suite 7C",
    price: 799,
  },
]

// Sample data for earnings
const earningsData = {
  today: 1299,
  thisWeek: 4995,
  thisMonth: 18750,
  pendingPayout: 12500,
}

// Sample data for ratings
const ratingsData = {
  average: 4.8,
  total: 124,
  breakdown: [
    { stars: 5, percentage: 85 },
    { stars: 4, percentage: 10 },
    { stars: 3, percentage: 3 },
    { stars: 2, percentage: 1 },
    { stars: 1, percentage: 1 },
  ],
}

export default function ProviderDashboardPage() {
  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-8">
        {/* Sidebar */}
        <div className="hidden md:block">
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Dashboard</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/provider/dashboard">
                    <Home className="mr-2 h-4 w-4" />
                    Overview
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/provider/dashboard/jobs">
                    <CalendarDays className="mr-2 h-4 w-4" />
                    My Jobs
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/provider/dashboard/earnings">
                    <DollarSign className="mr-2 h-4 w-4" />
                    Earnings
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/provider/dashboard/ratings">
                    <Star className="mr-2 h-4 w-4" />
                    Ratings & Reviews
                  </Link>
                </Button>
              </div>
            </div>
            <Separator />
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Account</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/provider/dashboard/profile">
                    <User className="mr-2 h-4 w-4" />
                    My Profile
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/provider/dashboard/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Provider Dashboard</h1>
            <p className="text-muted-foreground">Manage your jobs, earnings, and profile.</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">Today's Earnings</p>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">₹{earningsData.today}</div>
                  <p className="text-xs text-muted-foreground mt-1">From 2 completed jobs</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">This Week</p>
                    <BarChart className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">₹{earningsData.thisWeek}</div>
                  <p className="text-xs text-muted-foreground mt-1">From 10 completed jobs</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">This Month</p>
                    <CalendarDays className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">₹{earningsData.thisMonth}</div>
                  <p className="text-xs text-muted-foreground mt-1">From 38 completed jobs</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-muted-foreground">Pending Payout</p>
                    <CreditCard className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="text-2xl font-bold">₹{earningsData.pendingPayout}</div>
                  <p className="text-xs text-muted-foreground mt-1">Will be processed on 30th</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Jobs */}
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Jobs</CardTitle>
              <CardDescription>Your scheduled jobs for the next few days</CardDescription>
            </CardHeader>
            <CardContent>
              {upcomingJobs.length > 0 ? (
                <div className="space-y-4">
                  {upcomingJobs.map((job) => (
                    <div key={job.id} className="flex flex-col md:flex-row justify-between p-4 border rounded-lg">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{job.service}</h3>
                          <Badge variant="default">Confirmed</Badge>
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <CalendarDays className="mr-2 h-4 w-4" />
                          {new Date(job.date).toLocaleDateString("en-US", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="mr-2 h-4 w-4" />
                          {job.time}
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <User className="mr-2 h-4 w-4" />
                          {job.customer}
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <MapPin className="mr-2 h-4 w-4" />
                          {job.address}
                        </div>
                      </div>
                      <div className="flex flex-col items-end mt-4 md:mt-0 gap-2">
                        <p className="font-bold">₹{job.price}</p>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            Get Directions
                          </Button>
                          <Button variant="default" size="sm">
                            Start Job
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">You don't have any upcoming jobs.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Ratings & Reviews */}
          <Card>
            <CardHeader>
              <CardTitle>Ratings & Reviews</CardTitle>
              <CardDescription>Your performance based on customer feedback</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex flex-col items-center justify-center">
                  <div className="text-5xl font-bold mb-2">{ratingsData.average}</div>
                  <div className="flex items-center mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-5 w-5 ${
                          star <= Math.round(ratingsData.average)
                            ? "fill-primary text-primary"
                            : "text-muted-foreground"
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground">Based on {ratingsData.total} reviews</p>
                </div>
                <div className="space-y-3">
                  {ratingsData.breakdown.map((item) => (
                    <div key={item.stars} className="flex items-center gap-4">
                      <div className="flex items-center w-12">
                        <span className="text-sm font-medium">{item.stars}</span>
                        <Star className="h-4 w-4 ml-1" />
                      </div>
                      <Progress value={item.percentage} className="h-2 flex-1" />
                      <div className="w-12 text-right text-sm text-muted-foreground">{item.percentage}%</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function MapPin(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}
