import Link from "next/link"
import Image from "next/image"
import { Star } from "lucide-react"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface ServiceCardProps {
  service: {
    id: number
    title: string
    rating: number
    reviews: number
    price: number
    image: string
    category: string
  }
}

export default function ServiceCard({ service }: ServiceCardProps) {
  return (
    <Link href={`/services/${service.id}`}>
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-lg">
        <div className="relative h-48 w-full">
          <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
          <Badge className="absolute top-3 right-3">{service.category}</Badge>
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold text-lg mb-2">{service.title}</h3>
          <div className="flex items-center mb-2">
            <div className="flex items-center">
              <Star className="h-4 w-4 fill-primary text-primary mr-1" />
              <span className="font-medium">{service.rating}</span>
            </div>
            <span className="text-muted-foreground text-sm ml-2">({service.reviews} reviews)</span>
          </div>
          <div className="flex items-center justify-between">
            <p className="font-bold text-lg">₹{service.price}</p>
            <span className="text-sm text-muted-foreground">Starting price</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
