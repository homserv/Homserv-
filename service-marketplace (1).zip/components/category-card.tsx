import Link from "next/link"
import Image from "next/image"

import { Card, CardContent } from "@/components/ui/card"

interface CategoryCardProps {
  category: {
    id: number
    name: string
    icon: string
    image: string
  }
}

export default function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link href={`/categories/${category.id}`}>
      <Card className="overflow-hidden transition-all duration-200 hover:shadow-md hover:border-primary/50">
        <CardContent className="p-4 flex flex-col items-center text-center">
          <div className="relative h-16 w-16 rounded-full overflow-hidden mb-3">
            <Image src={category.image || "/placeholder.svg"} alt={category.name} fill className="object-cover" />
          </div>
          <h3 className="font-medium">{category.name}</h3>
        </CardContent>
      </Card>
    </Link>
  )
}
