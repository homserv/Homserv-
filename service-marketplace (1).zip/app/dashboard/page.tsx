import Link from "next/link"
import { CalendarDays, Clock, CreditCard, Home, Package, Settings, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"

// Sample data for upcoming bookings
const upcomingBookings = [
  {
    id: 1,
    service: "Home Cleaning",
    date: "2023-06-15",
    time: "10:00 AM",
    status: "confirmed",
    provider: "Sarah Johnson",
    price: 499,
  },
  {
    id: 2,
    service: "Salon at Home",
    date: "2023-06-20",
    time: "2:30 PM",
    status: "pending",
    provider: "Pending Assignment",
    price: 799,
  },
]

// Sample data for past bookings
const pastBookings = [
  {
    id: 3,
    service: "Plumbing Services",
    date: "2023-05-28",
    time: "11:00 AM",
    status: "completed",
    provider: "Michael Chen",
    price: 349,
  },
  {
    id: 4,
    service: "Electrician",
    date: "2023-05-15",
    time: "9:30 AM",
    status: "completed",
    provider: "Priya Sharma",
    price: 399,
  },
]

export default function DashboardPage() {
  return (
    <div className="container mx-auto px-4 md:px-6 py-8">
      <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-8">
        {/* Sidebar */}
        <div className="hidden md:block">
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Dashboard</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard">
                    <Home className="mr-2 h-4 w-4" />
                    Overview
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard/bookings">
                    <CalendarDays className="mr-2 h-4 w-4" />
                    My Bookings
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard/addresses">
                    <MapPin className="mr-2 h-4 w-4" />
                    My Addresses
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard/payments">
                    <CreditCard className="mr-2 h-4 w-4" />
                    Payment Methods
                  </Link>
                </Button>
              </div>
            </div>
            <Separator />
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Account</h3>
              <div className="space-y-1">
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard/profile">
                    <User className="mr-2 h-4 w-4" />
                    My Profile
                  </Link>
                </Button>
                <Button variant="ghost" className="w-full justify-start" asChild>
                  <Link href="/dashboard/settings">
                    <Settings className="mr-2 h-4 w-4" />
                    Settings
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back! Manage your bookings and account.</p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-2 bg-primary/10 rounded-full mb-4">
                    <Package className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium mb-1">Book a Service</h3>
                  <p className="text-sm text-muted-foreground mb-4">Browse and book services</p>
                  <Button className="w-full" asChild>
                    <Link href="/services">Browse Services</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-2 bg-primary/10 rounded-full mb-4">
                    <CalendarDays className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium mb-1">Manage Bookings</h3>
                  <p className="text-sm text-muted-foreground mb-4">View and manage your bookings</p>
                  <Button className="w-full" variant="outline" asChild>
                    <Link href="/dashboard/bookings">View Bookings</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-2 bg-primary/10 rounded-full mb-4">
                    <User className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium mb-1">My Profile</h3>
                  <p className="text-sm text-muted-foreground mb-4">Update your profile information</p>
                  <Button className="w-full" variant="outline" asChild>
                    <Link href="/dashboard/profile">Edit Profile</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="p-2 bg-primary/10 rounded-full mb-4">
                    <CreditCard className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium mb-1">Payment Methods</h3>
                  <p className="text-sm text-muted-foreground mb-4">Manage your payment methods</p>
                  <Button className="w-full" variant="outline" asChild>
                    <Link href="/dashboard/payments">Manage Payments</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bookings */}
          <Card>
            <CardHeader>
              <CardTitle>My Bookings</CardTitle>
              <CardDescription>View and manage your service bookings</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="upcoming">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="past">Past</TabsTrigger>
                </TabsList>
                <TabsContent value="upcoming" className="pt-4">
                  {upcomingBookings.length > 0 ? (
                    <div className="space-y-4">
                      {upcomingBookings.map((booking) => (
                        <div
                          key={booking.id}
                          className="flex flex-col md:flex-row justify-between p-4 border rounded-lg"
                        >
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{booking.service}</h3>
                              <Badge variant={booking.status === "confirmed" ? "default" : "outline"}>
                                {booking.status === "confirmed" ? "Confirmed" : "Pending"}
                              </Badge>
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <CalendarDays className="mr-2 h-4 w-4" />
                              {new Date(booking.date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Clock className="mr-2 h-4 w-4" />
                              {booking.time}
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <User className="mr-2 h-4 w-4" />
                              {booking.provider}
                            </div>
                          </div>
                          <div className="flex flex-col items-end mt-4 md:mt-0 gap-2">
                            <p className="font-bold">₹{booking.price}</p>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                Reschedule
                              </Button>
                              <Button variant="destructive" size="sm">
                                Cancel
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">You don't have any upcoming bookings.</p>
                      <Button className="mt-4" asChild>
                        <Link href="/services">Book a Service</Link>
                      </Button>
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="past" className="pt-4">
                  {pastBookings.length > 0 ? (
                    <div className="space-y-4">
                      {pastBookings.map((booking) => (
                        <div
                          key={booking.id}
                          className="flex flex-col md:flex-row justify-between p-4 border rounded-lg"
                        >
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{booking.service}</h3>
                              <Badge variant="secondary">Completed</Badge>
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <CalendarDays className="mr-2 h-4 w-4" />
                              {new Date(booking.date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Clock className="mr-2 h-4 w-4" />
                              {booking.time}
                            </div>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <User className="mr-2 h-4 w-4" />
                              {booking.provider}
                            </div>
                          </div>
                          <div className="flex flex-col items-end mt-4 md:mt-0 gap-2">
                            <p className="font-bold">₹{booking.price}</p>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                              <Button variant="secondary" size="sm">
                                Book Again
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">You don't have any past bookings.</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function MapPin(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
      <circle cx="12" cy="10" r="3" />
    </svg>
  )
}
