import { NextResponse } from "next/server"

// Sample data for services
const services = [
  {
    id: 1,
    title: "Home Cleaning",
    description: "Professional home cleaning services for a spotless home.",
    price: 499,
    image: "/placeholder.svg?height=200&width=300",
    category: "Cleaning",
  },
  {
    id: 2,
    title: "Salon at Home",
    description: "Professional beauty services in the comfort of your home.",
    price: 799,
    image: "/placeholder.svg?height=200&width=300",
    category: "Beauty",
  },
  {
    id: 3,
    title: "Plumbing Services",
    description: "Expert plumbing services for all your needs.",
    price: 349,
    image: "/placeholder.svg?height=200&width=300",
    category: "Repairs",
  },
  {
    id: 4,
    title: "Electrician",
    description: "Professional electrical services for your home.",
    price: 399,
    image: "/placeholder.svg?height=200&width=300",
    category: "Repairs",
  },
  {
    id: 5,
    title: "Pest Control",
    description: "Effective pest control services for a pest-free home.",
    price: 599,
    image: "/placeholder.svg?height=200&width=300",
    category: "Cleaning",
  },
  {
    id: 6,
    title: "Painting",
    description: "Professional painting services for your home.",
    price: 1499,
    image: "/placeholder.svg?height=200&width=300",
    category: "Painting",
  },
]

export async function GET(request: Request) {
  // Get the URL from the request
  const url = new URL(request.url)

  // Get query parameters
  const category = url.searchParams.get("category")
  const search = url.searchParams.get("search")

  // Filter services based on query parameters
  let filteredServices = [...services]

  if (category) {
    filteredServices = filteredServices.filter((service) => service.category.toLowerCase() === category.toLowerCase())
  }

  if (search) {
    filteredServices = filteredServices.filter(
      (service) =>
        service.title.toLowerCase().includes(search.toLowerCase()) ||
        service.description.toLowerCase().includes(search.toLowerCase()),
    )
  }

  // Return the filtered services
  return NextResponse.json(filteredServices)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    // Validate the request body
    if (!body.title || !body.description || !body.price || !body.category) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real application, you would save this to a database
    // For this example, we'll just return the created service with a mock ID
    const newService = {
      id: services.length + 1,
      title: body.title,
      description: body.description,
      price: body.price,
      image: body.image || "/placeholder.svg?height=200&width=300",
      category: body.category,
    }

    return NextResponse.json(newService, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create service" }, { status: 500 })
  }
}
