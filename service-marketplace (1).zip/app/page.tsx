import { ArrowRight, CheckCircle, Clock, MapPin, Search, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import ServiceCard from "@/components/service-card"
import CategoryCard from "@/components/category-card"

// Sample data for popular services
const popularServices = [
  {
    id: 1,
    title: "Home Cleaning",
    rating: 4.8,
    reviews: 1240,
    price: 499,
    image: "/placeholder.svg?height=200&width=300",
    category: "Cleaning",
  },
  {
    id: 2,
    title: "Salon at Home",
    rating: 4.7,
    reviews: 980,
    price: 799,
    image: "/placeholder.svg?height=200&width=300",
    category: "Beauty",
  },
  {
    id: 3,
    title: "Plumbing Services",
    rating: 4.6,
    reviews: 750,
    price: 349,
    image: "/placeholder.svg?height=200&width=300",
    category: "Repairs",
  },
  {
    id: 4,
    title: "Electrician",
    rating: 4.5,
    reviews: 620,
    price: 399,
    image: "/placeholder.svg?height=200&width=300",
    category: "Repairs",
  },
]

// Sample data for service categories
const categories = [
  {
    id: 1,
    name: "Cleaning",
    icon: "🧹",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 2,
    name: "Beauty",
    icon: "💇‍♀️",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 3,
    name: "Repairs",
    icon: "🔧",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 4,
    name: "Appliances",
    icon: "🔌",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 5,
    name: "Painting",
    icon: "🎨",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: 6,
    name: "Pest Control",
    icon: "🐜",
    image: "/placeholder.svg?height=100&width=100",
  },
]

// Sample data for how it works steps
const howItWorks = [
  {
    id: 1,
    title: "Choose a service",
    description: "Browse through our wide range of professional services",
    icon: Search,
  },
  {
    id: 2,
    title: "Book a time slot",
    description: "Select a convenient date and time for your service",
    icon: Clock,
  },
  {
    id: 3,
    title: "Get it done",
    description: "Our verified professionals will get the job done",
    icon: CheckCircle,
  },
]

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-primary text-primary-foreground py-20">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter">
                Professional Services at Your Doorstep
              </h1>
              <p className="text-lg md:text-xl text-primary-foreground/80 max-w-[600px]">
                Book trusted professionals for your home services, beauty needs, repairs, and more.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md">
                <div className="relative flex-1">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Enter your location"
                    className="pl-10 bg-background text-foreground"
                  />
                </div>
                <Button size="lg">Find Services</Button>
              </div>
            </div>
            <div className="hidden md:block">
              <img
                src="/placeholder.svg?height=400&width=500"
                alt="Professional services illustration"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight mb-4">Browse by Category</h2>
            <p className="text-muted-foreground max-w-[700px]">
              Explore our wide range of professional services across various categories
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {categories.map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        </div>
      </section>

      {/* Popular Services Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold tracking-tight mb-2">Popular Services</h2>
              <p className="text-muted-foreground">Most booked services by our customers</p>
            </div>
            <Button variant="outline" className="mt-4 md:mt-0">
              View All Services <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularServices.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight mb-4">How It Works</h2>
            <p className="text-muted-foreground max-w-[700px]">Book a service in just a few simple steps</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {howItWorks.map((step) => (
              <Card key={step.id} className="border-none shadow-md">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center">
                    <div className="bg-primary/10 p-3 rounded-full mb-4">
                      <step.icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col items-center justify-center mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight mb-4">What Our Customers Say</h2>
            <p className="text-muted-foreground max-w-[700px]">
              Don't just take our word for it, hear what our customers have to say
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-none shadow-md">
                <CardContent className="pt-6">
                  <div className="flex flex-col">
                    <div className="flex items-center mb-4">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star key={star} className="h-4 w-4 fill-primary text-primary" />
                        ))}
                      </div>
                    </div>
                    <p className="text-muted-foreground mb-4">
                      "The service was excellent! The professional arrived on time and did a fantastic job. Will
                      definitely book again."
                    </p>
                    <div className="flex items-center mt-auto">
                      <div className="h-10 w-10 rounded-full bg-muted mr-3"></div>
                      <div>
                        <p className="font-medium">Customer Name</p>
                        <p className="text-sm text-muted-foreground">Service: Home Cleaning</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-4 text-center md:text-left">
              <h2 className="text-3xl font-bold tracking-tight">Become a Service Provider</h2>
              <p className="text-primary-foreground/80 max-w-[500px]">
                Join our platform as a service provider and grow your business
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="secondary" size="lg">
                Learn More
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="bg-transparent text-primary-foreground border-primary-foreground hover:bg-primary-foreground hover:text-primary"
              >
                Register Now
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
