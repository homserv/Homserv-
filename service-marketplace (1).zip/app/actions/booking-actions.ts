"use server"

import { revalidatePath } from "next/cache"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"

const prisma = new PrismaClient()

export async function createBooking(formData: FormData) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return {
        success: false,
        message: "You must be logged in to book a service",
      }
    }

    const userId = Number.parseInt((session.user as any).id)
    const serviceId = Number.parseInt(formData.get("serviceId") as string)
    const date = formData.get("date") as string
    const time = formData.get("time") as string
    const addressId = Number.parseInt(formData.get("addressId") as string)
    const price = Number.parseFloat(formData.get("price") as string)
    const notes = (formData.get("notes") as string) || null
    const providerId = formData.get("providerId") ? Number.parseInt(formData.get("providerId") as string) : null

    // Validate the input
    if (!serviceId || !date || !time || !addressId || !price) {
      return {
        success: false,
        message: "Please fill in all required fields",
      }
    }

    // Create the booking
    const booking = await prisma.booking.create({
      data: {
        userId,
        serviceId,
        providerId,
        date,
        time,
        addressId,
        price,
        notes,
        status: "pending",
      },
    })

    revalidatePath("/dashboard/bookings")

    return {
      success: true,
      message: "Booking created successfully",
      booking,
    }
  } catch (error) {
    console.error("Error creating booking:", error)
    return {
      success: false,
      message: "Failed to create booking. Please try again.",
    }
  }
}

export async function cancelBooking(bookingId: number) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return {
        success: false,
        message: "You must be logged in to cancel a booking",
      }
    }

    const userId = Number.parseInt((session.user as any).id)

    // Check if the booking belongs to the user
    const booking = await prisma.booking.findUnique({
      where: {
        id: bookingId,
      },
    })

    if (!booking) {
      return {
        success: false,
        message: "Booking not found",
      }
    }

    if (booking.userId !== userId && (session.user as any).role !== "admin") {
      return {
        success: false,
        message: "You are not authorized to cancel this booking",
      }
    }

    // Update the booking status
    await prisma.booking.update({
      where: {
        id: bookingId,
      },
      data: {
        status: "cancelled",
      },
    })

    revalidatePath("/dashboard/bookings")

    return {
      success: true,
      message: "Booking cancelled successfully",
    }
  } catch (error) {
    console.error("Error cancelling booking:", error)
    return {
      success: false,
      message: "Failed to cancel booking. Please try again.",
    }
  }
}

export async function completeBooking(bookingId: number) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return {
        success: false,
        message: "You must be logged in to complete a booking",
      }
    }

    // Only providers or admins can mark a booking as complete
    if ((session.user as any).role !== "provider" && (session.user as any).role !== "admin") {
      return {
        success: false,
        message: "You are not authorized to complete this booking",
      }
    }

    const providerId = Number.parseInt((session.user as any).id)

    // Check if the booking belongs to the provider
    const booking = await prisma.booking.findUnique({
      where: {
        id: bookingId,
      },
    })

    if (!booking) {
      return {
        success: false,
        message: "Booking not found",
      }
    }

    if (booking.providerId !== providerId && (session.user as any).role !== "admin") {
      return {
        success: false,
        message: "You are not authorized to complete this booking",
      }
    }

    // Update the booking status
    await prisma.booking.update({
      where: {
        id: bookingId,
      },
      data: {
        status: "completed",
      },
    })

    revalidatePath("/provider/dashboard/jobs")

    return {
      success: true,
      message: "Booking marked as completed",
    }
  } catch (error) {
    console.error("Error completing booking:", error)
    return {
      success: false,
      message: "Failed to complete booking. Please try again.",
    }
  }
}
