// This file defines the database schema for the service marketplace platform
// In a real application, you would use Prisma, Drizzle, or another ORM

export type User = {
  id: number
  name: string
  email: string
  password: string // In a real app, this would be hashed
  phone: string
  role: "customer" | "provider" | "admin"
  createdAt: Date
  updatedAt: Date
}

export type Address = {
  id: number
  userId: number
  addressLine1: string
  addressLine2: string | null
  city: string
  state: string
  postalCode: string
  isDefault: boolean
  createdAt: Date
  updatedAt: Date
}

export type Category = {
  id: number
  name: string
  description: string | null
  image: string | null
  createdAt: Date
  updatedAt: Date
}

export type Service = {
  id: number
  title: string
  description: string
  longDescription: string | null
  price: number
  image: string | null
  categoryId: number
  duration: string
  createdAt: Date
  updatedAt: Date
}

export type ServiceInclusion = {
  id: number
  serviceId: number
  description: string
  isIncluded: boolean
  createdAt: Date
  updatedAt: Date
}

export type Provider = {
  id: number
  userId: number
  bio: string | null
  experience: string | null
  isVerified: boolean
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

export type ProviderService = {
  id: number
  providerId: number
  serviceId: number
  price: number | null // If null, use the default service price
  isAvailable: boolean
  createdAt: Date
  updatedAt: Date
}

export type Booking = {
  id: number
  userId: number
  serviceId: number
  providerId: number | null
  date: string
  time: string
  status: "pending" | "confirmed" | "in_progress" | "completed" | "cancelled"
  addressId: number
  price: number
  notes: string | null
  createdAt: Date
  updatedAt: Date
}

export type Review = {
  id: number
  bookingId: number
  userId: number
  providerId: number
  rating: number
  comment: string | null
  createdAt: Date
  updatedAt: Date
}

export type Payment = {
  id: number
  bookingId: number
  amount: number
  status: "pending" | "completed" | "failed" | "refunded"
  paymentMethod: string
  transactionId: string | null
  createdAt: Date
  updatedAt: Date
}
